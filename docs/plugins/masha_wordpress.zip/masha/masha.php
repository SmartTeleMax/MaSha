<?php
/*
Plugin Name: MASHA - Mark & Share
Plugin URI: http://www.mashajs.com/
Description: MASHA – is a JavaScript utility allowing you to mark interesting parts of web page content and share it.
Version: 0.1 beta
Author: Stas Bonbin, Harut Dagesyan, Artem Geller, Denis Otkidach
Author URI: http://www.mashajs.com/
License: MIT
*/

// Install Masha
function rw_masha() {
	$opt_selectable_name = 'mt_selectable';
	$opt_marker_name = 'mt_marker';
	$opt_ignored_name = 'mt_ignored';
	$opt_onMark_name = 'mt_onMark';
	$opt_onUnmark_name = 'mt_onUnmark';
	$opt_onHashRead_name = 'mt_onHashRead';
	
	$opt_selectable_val = get_option( $opt_selectable_name );
	$opt_marker_val = get_option( $opt_marker_name );
	$opt_ignored_val = get_option( $opt_ignored_name );
	$opt_onMark_val = get_option( $opt_onMark_name );
	$opt_onUnmark_val = get_option( $opt_onUnmark_name );
	$opt_onHashRead_val = get_option( $opt_onHashRead_name );



?>

<!--[IF IE]>
<script type="text/javascript" src="<?php echo plugins_url(); ?>/masha/js/ierange.js"></script>
<![ENDIF]-->
<script type="text/javascript" src="<?php echo plugins_url(); ?>/masha/js/masha.js"></script>​
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url(); ?>/masha/css/masha.css">

<script type="text/javascript">

var MaSha_opt = {
		'selectable': '<?php echo $opt_selectable_val; ?>',
		'marker': '<?php echo $opt_marker_val; ?>',
		'ignored': <?php echo $opt_ignored_val; ?>,
		'onSelected': <?php echo $opt_onMark_val; ?>,
		'onDeselected': <?php echo $opt_onUnmark_val; ?>,
		'onHashRead': <?php echo $opt_onHashRead_val; ?>
	};

if (window.addEventListener){
    window.addEventListener('load', function(){
    // can be called by domready
    MaSha.instance = new MaSha(MaSha_opt);
    }, false);
} else {
    window.attachEvent('onload', function(){
    // can be called by domready
    MaSha.instance = new MaSha(MaSha_opt);
    });
}
</script>


<?php

}

function add_marker() {
	echo '<a href="#" id="txtselect_marker"></a>';
}


// And execute the function
add_action('wp_head', 'rw_masha');

// Add marker
add_action('wp_footer', 'add_marker');



// Hook for adding admin menus
add_action('admin_menu', 'mt_add_pages');

// action function for above hook
function mt_add_pages() {
    // Add a new submenu under Options:
    add_options_page('Masha settings', 'Masha settings', 8, 'mashasettings', 'mt_options_page');
}

// mt_options_page() displays the page content for the Test Options submenu
function mt_options_page() {

    // variables for the field and option names 
    $opt_selectable_name = 'mt_selectable';
	$opt_marker_name = 'mt_marker';
	$opt_ignored_name = 'mt_ignored';
	$opt_onMark_name = 'mt_onMark';
	$opt_onUnmark_name = 'mt_onUnmark';
	$opt_onHashRead_name = 'mt_onHashRead';
	
	
    $hidden_field_name = 'mt_submit_hidden';
    
	$data_selectable_name = 'mt_selectable';
	$data_marker_name = 'mt_marker';
	$data_ignored_name = 'mt_ignored';
	$data_onMark_name = 'mt_onMark';
	$data_onUnmark_name = 'mt_onUnmark';
	$data_onHashRead_name = 'mt_onHashRead';


	//$data_field_name = 'mt_selectable';

    // Read in existing option value from database
    // $opt_val = get_option( $opt_name );

	$opt_selectable_val = get_option( $opt_selectable_name );
	$opt_marker_val = get_option( $opt_marker_name );
	$opt_ignored_val = get_option( $opt_ignored_name );
	$opt_onMark_val = get_option( $opt_onMark_name );
	$opt_onUnmark_val = get_option( $opt_onUnmark_name );
	$opt_onHashRead_val = get_option( $opt_onHashRead_name );

    // See if the user has posted us some information
    // If they did, this hidden field will be set to 'Y'
    if( $_POST[ $hidden_field_name ] == 'Y' ) {
        // Read their posted value
        $opt_selectable_val = $_POST[ $data_selectable_name ];
		$opt_marker_val = $_POST[ $data_marker_name ];
		$opt_ignored_val = $_POST[ $data_ignored_name ];
		$opt_onMark_val = $_POST[ $data_onMark_name ];
		$opt_onUnmark_val = $_POST[ $data_onUnmark_name ];
		$opt_onHashRead_val = $_POST[ $data_onHashRead_name ];

        // Save the posted value in the database
        update_option( $opt_selectable_name, $opt_selectable_val );
		update_option( $opt_marker_name, $opt_marker_val );
		update_option( $opt_ignored_name, $opt_ignored_val );
		update_option( $opt_onMark_name, $opt_onMark_val );
		update_option( $opt_onUnmark_name, $opt_onUnmark_val );
		update_option( $opt_onHashRead_name, $opt_onHashRead_val );


        // Put an options updated message on the screen

?>
<div class="updated"><p><strong><?php _e('Options saved.', 'mt_trans_domain' ); ?></strong></p></div>
<?php

    }

    // Now display the options editing screen

    echo '<div class="wrap">';

    // header

    echo "<h2>" . __( 'Masha Options', 'mt_trans_domain' ) . "</h2>";

    // options form
    
    ?>

<form name="form1" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
<input type="hidden" name="<?php echo $hidden_field_name; ?>" value="Y">

<p><?php _e("HTML-element (or id of it) determining selectable area:", 'mt_trans_domain' ); ?> </br>
<input type="text" name="<?php echo $data_selectable_name; ?>" value="<?php echo (empty($opt_selectable_val) ? 'main' : $opt_selectable_val); ?>" size="40">
</p>
<p><?php _e("HTML-element (or id of it) of marker icon appearing when some text is selected with mouse:", 'mt_trans_domain' ); ?> </br>
<input type="text" name="<?php echo $data_marker_name; ?>" value="<?php echo (empty($opt_marker_val) ? 'txtselect_marker' : $opt_marker_val); ?>" size="40">
</p>
<p><?php _e("Predicate function of one argument HTML element returning true to forbid selection in some elements inside selectable area and false otherwise:", 'mt_trans_domain' ); ?> </br>
<textarea style="width: 400px; height: 150px;" name="<?php echo $data_ignored_name; ?>"><?php echo (empty($opt_ignored_val) ? 'null' : $opt_ignored_val); ?></textarea>
</p>
<p><?php _e("Callback function called when user click on marker:", 'mt_trans_domain' ); ?> </br>
<textarea style="width: 400px; height: 150px;" name="<?php echo $data_onMark_name; ?>"><?php echo (empty($opt_onMark_val) ? 'null' : $opt_onMark_val); ?></textarea>
</p>
<p><?php _e("Callback function called when user deletes mark:", 'mt_trans_domain' ); ?> </br>
<textarea style="width: 400px; height: 150px;" name="<?php echo $data_onUnmark_name; ?>"><?php echo (empty($opt_onUnmark_val) ? 'null' : $opt_onUnmark_val); ?></textarea>
</p>
<p><?php _e("function called when page is loaded and marks are restored (by default scrolls to first marked fragment):", 'mt_trans_domain' ); ?> </br>
<textarea style="width: 400px; height: 150px;" name="<?php echo $data_onHashRead_name; ?>"><?php echo (empty($opt_onHashRead_val) ? 'null' : $opt_onHashRead_val); ?></textarea>
</p>

<hr />

<p class="submit">
<input type="submit" name="Submit" value="<?php _e('Update Options', 'mt_trans_domain' ) ?>" />
</p>

</form>
</div>

<?php
 
}



?>