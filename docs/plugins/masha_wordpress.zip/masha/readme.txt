=== Plugin Name ===
Contributors: Stas Bonbin, Harut Dagesian, Artem Geller, Denis Otkidach
Donate link: http://www.mashajs.com/
Tags: mark, share, javascript
Requires at least: 3.0.0
Tested up to: 3.2.0
Stable tag: 1.0.0

MASHA (short for Mark & Share) is a JavaScript utility allowing you to mark interesting parts of web page content and share it.
== Description ==
There is a new function at the official site of the President of Russia  (which we, while writing a code, named "Masha" � from English words mark & share)

MASHA (short for Mark & Share) is a JavaScript utility allowing you to mark interesting parts of web page content and share it. Just select text (paragraphs, sentences, words) on MASHA powered page and copy generated URL from location bar. 

== Installation ==
1. Upload `masha/` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Set options on Settings section -> Masha settings

== Frequently Asked Questions == 
None at this moment.

== Upgrade Notice == 
Its recommended to flush the cache after upgrading.

== Screenshots ==
Not relevant.

== Changelog ==
= 0.1 =
* Beta version